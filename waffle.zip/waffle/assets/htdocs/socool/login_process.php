<?php

session_start();

require "connect.php";

$username = $_POST["username"];
$password = $_POST["password"];

$sql = "SELECT * FROM members 
        WHERE username = '$username' 
        AND password = '$password'";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) == 1) {

    $user = mysqli_fetch_assoc($result);

    $_SESSION["fullname"] = $user["fullname"];
    $_SESSION["email"] = $user["email"];

    header("Location: result.php");
    exit();

} else {

    echo "Username หรือ Password ไม่ถูกต้อง";
}

mysqli_close($conn);

?>