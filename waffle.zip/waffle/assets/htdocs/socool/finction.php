<?php
    function calarea($w,$h){
        return $w*$h;
    }

    $area = calarea(10,5);
    echo "พื้นที่สี่เหลี่ยม = ".$area;
?>