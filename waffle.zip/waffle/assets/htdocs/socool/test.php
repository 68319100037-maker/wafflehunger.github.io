<?php
$num1="10";
$num2="2";
$total=$num1+$num2;

echo "<p>ตัวเลขตัวที่ 1 มีค่า = $num1</p>";
echo "<p>ตัวเลขตัวที่ 2 มีค่า = $num2</p>";
echo "<p>ผลบวกทั้งสองตัว = $total</p>";
?>