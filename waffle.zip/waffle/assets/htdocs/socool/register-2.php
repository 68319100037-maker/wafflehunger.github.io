<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>สมัครสมาชิก</title>
</head>
<body>

<h2>สมัครสมาชิก</h2>

<form action="register_process.php" method="post">

    ชื่อ - นามสกุล
    <input type="text" name="fullname">
    <br><br>

    Username
    <input type="text" name="username">
    <br><br>

    Email
    <input type="email" name="email">
    <br><br>

    Password
    <input type="password" name="password">
    <br><br>

    <input type="submit" value="สมัครสมาชิก">

</form>

</body>
</html>