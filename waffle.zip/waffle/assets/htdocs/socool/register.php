<html>
    <head></head>
    <body>
    <?php
    $username= $_POST['username'];
    $password= $_POST['password'];

    echo "<h2>ข้อมูลสมาชิก</h2>";
    echo "username : ".$username."<br>";
    echo "password : ".$password."<br>";
?>
</form>
</body>
</html>