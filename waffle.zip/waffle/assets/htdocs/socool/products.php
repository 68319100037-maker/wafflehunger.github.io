<?php
include 'connect.php'; // เรียกใช้ไฟล์เชื่อมต่อฐานข้อมูล

// ระบบสลับสถานะสินค้า ( active <-> out_of_stock )
if (isset($_GET['toggle_id']) && isset($_GET['current_status'])) {
    $toggle_id = intval($_GET['toggle_id']);
    $new_status = ($_GET['current_status'] == 'active') ? 'out_of_stock' : 'active';
    
    $stmt = $conn->prepare("UPDATE products SET status = ? WHERE product_id = ?");
    $stmt->bind_param("si", $new_status, $toggle_id);
    $stmt->execute();
    
    header("Location: products.php");
    exit();
}

// ดึงรายการสินค้าทั้งหมด
$result = $conn->query("SELECT * FROM products ORDER BY product_id DESC");
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>รายการสินค้า - Waffle Hunger</title>
    <!-- Bootstrap 5 CSS & FontAwesome -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        body { background-color: #f8fafc; font-family: 'Kanit', sans-serif; }
        .product-card { border: none; border-radius: 15px; transition: all 0.2s; }
        .product-card:hover { transform: translateY(-5px); box-shadow: 0 10px 20px rgba(0,0,0,0.08); }
        .badge-active { background-color: #dcfce7; color: #15803d; }
        .badge-out { background-color: #fee2e2; color: #b91c1c; }
    </style>
</head>
<body>

<div class="container py-5">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold text-warning-emphasis mb-0">
                <i class="fa-solid fa-stroopwafel me-2"></i>จัดการเมนูสินค้า (Products)
            </h2>
            <p class="text-muted mb-0">เมนูวาฟเฟิล เครื่องดื่ม และท็อปปิ้งทั้งหมดในร้าน Waffle Hunger</p>
        </div>
        <a href="dashboard.php" class="btn btn-outline-secondary rounded-pill px-4">
            <i class="fa-solid fa-arrow-left me-1"></i> กลับหน้า Dashboard
        </a>
    </div>

    <!-- Product Grid -->
    <div class="row g-4">
        <?php if ($result && $result->num_rows > 0): ?>
            <?php while($row = $result->fetch_assoc()): ?>
                <div class="col-md-4 col-sm-6">
                    <div class="card product-card h-100 shadow-sm p-3 bg-white">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <span class="badge bg-light text-dark border fs-6">ID: #<?php echo $row['product_id']; ?></span>
                            <?php if($row['status'] == 'active'): ?>
                                <span class="badge badge-active px-3 py-2 rounded-pill">พร้อมขาย</span>
                            <?php else: ?>
                                <span class="badge badge-out px-3 py-2 rounded-pill">สินค้าหมด</span>
                            <?php endif; ?>
                        </div>

                        <h5 class="card-title fw-bold text-dark mt-2"><?php echo htmlspecialchars($row['product_name']); ?></h5>
                        <p class="card-text text-muted small flex-grow-1"><?php echo htmlspecialchars($row['description']); ?></p>

                        <div class="d-flex justify-content-between align-items-center mt-3 pt-3 border-top">
                            <div>
                                <small class="text-muted d-block">ราคาขาย</small>
                                <span class="fs-4 fw-bold text-amber text-warning-emphasis">
                                    <?php echo number_format($row['price'], 2); ?> ฿
                                </span>
                            </div>
                            <!-- ปุ่มสลับสถานะ -->
                            <a href="products.php?toggle_id=<?php echo $row['product_id']; ?>&current_status=<?php echo $row['status']; ?>" 
                               class="btn btn-sm <?php echo $row['status'] == 'active' ? 'btn-outline-danger' : 'btn-outline-success'; ?> rounded-pill px-3">
                               <i class="fa-solid fa-arrows-rotate me-1"></i>
                               <?php echo $row['status'] == 'active' ? 'ปิดการขาย' : 'เปิดการขาย'; ?>
                            </a>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-12 text-center py-5">
                <i class="fa-solid fa-box-open fs-1 text-muted mb-3"></i>
                <h5 class="text-muted">ยังไม่มีรายการสินค้าในระบบ (ลองรัน seed_data.php ก่อนนะครับ)</h5>
            </div>
        <?php endif; ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>