<?php

session_start();

if (!isset($_SESSION["fullname"])) {
    header("Location: login.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>ข้อมูลผู้ใช้งาน</title>
</head>
<body>

    <h2>ข้อมูลผู้ใช้งาน</h2>

    <p>
        <strong>ชื่อ-สกุล:</strong>
        <?php echo $_SESSION["fullname"]; ?>
    </p>

    <p>
        <strong>Email:</strong>
        <?php echo $_SESSION["email"]; ?>
    </p>

</body>
</html>