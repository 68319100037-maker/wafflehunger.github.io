<html>
<head></head>
<body>
<?php
    $fname = $_GET['fname'];
    $lasname = $_GET['lasname'];
    $gender = $_GET['gender'];

    echo "<h2>ข้อมูลสมาชิก</h2>";
    echo "ชื่อ : ".$fname."<br>";
    echo "นามสกุล : ".$lasname."<br>";
    echo "เพศ : ".$gender."<br>";
?>
</form>
</body>
</html>