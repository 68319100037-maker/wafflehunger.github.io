<html>
    <head></head>
    <body>
        <h2>สมัครสมาชิก</h2>

        <form action="register.php" method="post">
            username : <input type="text" name="username"><br><br>
            password : <input type="password" name="password"><br><br>
            <input type="submit" value="สมัครสมาชิก">
            <input type="reset" value="ล้างข้อมูล">

</form>
</body>
</html>