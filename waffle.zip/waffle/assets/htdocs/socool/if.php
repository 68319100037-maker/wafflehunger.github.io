<?php
    $total = 1200;
    if($total >= 15000){
        echo 'ส่งฟรี';
    }elseif($total >= 800){
        echo 'ค่าส่ง 30 บาท';
    }else{
        echo 'ค่าส่ง 50 บาท';
    }
?>