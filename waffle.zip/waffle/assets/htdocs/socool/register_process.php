<?php

require "connect.php";

$fullname = $_POST["fullname"];
$username = $_POST["username"];
$email = $_POST["email"];
$password = $_POST["password"];

$sql = "INSERT INTO members
        (fullname, username, email, password)
        VALUES
        ('$fullname', '$username', '$email', '$password')";

if (mysqli_query($conn, $sql)) {

    echo "สมัครสมาชิกสำเร็จ";

} else {

    echo "เกิดข้อผิดพลาด: " . mysqli_error($conn);

}

mysqli_close($conn);

?>