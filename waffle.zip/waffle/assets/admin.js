/* =========================================================
   Waffle Hunger — admin.js
========================================================= */

function initSalesChart(labels, data) {
  const ctx = document.getElementById('salesChart');
  if (!ctx || typeof Chart === 'undefined') return;

  const gradient = ctx.getContext('2d').createLinearGradient(0, 0, 0, 260);
  gradient.addColorStop(0, 'rgba(207,154,63,.35)');
  gradient.addColorStop(1, 'rgba(207,154,63,0)');

  new Chart(ctx, {
    type: 'line',
    data: {
      labels: labels,
      datasets: [{
        label: 'ยอดขาย',
        data: data,
        borderColor: '#cf9a3f',
        backgroundColor: gradient,
        borderWidth: 3,
        pointBackgroundColor: '#cf9a3f',
        pointBorderColor: '#fff',
        pointBorderWidth: 2,
        pointRadius: 4,
        tension: 0.4,
        fill: true,
      }]
    },
    options: {
      plugins: { legend: { display: false } },
      scales: {
        y: { beginAtZero: true, grid: { color: '#f0e9db' }, ticks: { callback: function (v) { return v / 1000 + 'K'; } } },
        x: { grid: { display: false } }
      }
    }
  });
}

function initStatusChart(data) {
  const ctx = document.getElementById('statusChart');
  if (!ctx || typeof Chart === 'undefined') return;

  new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ['รอชำระเงิน', 'กำลังจัดเตรียม', 'พร้อมรับ', 'เสร็จสิ้น'],
      datasets: [{
        data: data,
        backgroundColor: ['#e6c374', '#a9772a', '#2b2118', '#d8c3a0'],
        borderWidth: 0,
      }]
    },
    options: {
      cutout: '68%',
      plugins: { legend: { display: false } }
    }
  });
}
