/* =========================================================
   Waffle Hunger — app.js
========================================================= */

/* ---------- Mobile nav ---------- */
document.addEventListener('DOMContentLoaded', function () {
  const burger = document.getElementById('navBurger');
  const links = document.getElementById('navLinks');
  if (burger && links) {
    burger.addEventListener('click', function () {
      links.classList.toggle('open');
    });
  }

  initHeroSlider();
  renderCartBadge();
  bindCartUI();
  bindAddToCartButtons();
  bindQtyControl();
  initMenuFilters();
});

/* ---------- Hero slider (auto every 5s) ---------- */
function initHeroSlider() {
  const slides = document.querySelectorAll('.hero-slide');
  const dots = document.querySelectorAll('.hero-dots button');
  if (!slides.length) return;
  let current = 0;

  function show(i) {
    slides.forEach(function (s) { s.classList.remove('active'); });
    dots.forEach(function (d) { d.classList.remove('active'); });
    slides[i].classList.add('active');
    if (dots[i]) dots[i].classList.add('active');
    current = i;
  }

  dots.forEach(function (dot, i) {
    dot.addEventListener('click', function () { show(i); });
  });

  setInterval(function () {
    show((current + 1) % slides.length);
  }, 5000);
}

/* ---------- Toast ---------- */
function showToast(message) {
  let toast = document.getElementById('toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'toast';
    toast.className = 'toast';
    document.body.appendChild(toast);
  }
  toast.innerHTML = message;
  toast.classList.add('show');
  clearTimeout(window.__toastTimer);
  window.__toastTimer = setTimeout(function () {
    toast.classList.remove('show');
  }, 2200);
}

/* ---------- Cart (localStorage) ---------- */
const CART_KEY = 'waffle_hunger_cart';

function getCart() {
  try {
    return JSON.parse(localStorage.getItem(CART_KEY)) || [];
  } catch (e) {
    return [];
  }
}

function saveCart(cart) {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
  renderCartBadge();
  renderCartItems();
}

function addToCart(id, name, price, icon, qty) {
  qty = qty || 1;
  const cart = getCart();
  const existing = cart.find(function (i) { return i.id === id; });
  if (existing) {
    existing.qty += qty;
  } else {
    cart.push({ id: id, name: name, price: price, icon: icon, qty: qty });
  }
  saveCart(cart);
  showToast('🧇 เพิ่ม "' + name + '" ลงตะกร้าแล้ว');
}

function removeFromCart(id) {
  let cart = getCart();
  cart = cart.filter(function (i) { return i.id !== id; });
  saveCart(cart);
}

function updateCartQty(id, delta) {
  const cart = getCart();
  const item = cart.find(function (i) { return i.id === id; });
  if (!item) return;
  item.qty += delta;
  if (item.qty <= 0) {
    removeFromCart(id);
    return;
  }
  saveCart(cart);
}

function cartTotal() {
  return getCart().reduce(function (sum, i) { return sum + i.price * i.qty; }, 0);
}

function cartCount() {
  return getCart().reduce(function (sum, i) { return sum + i.qty; }, 0);
}

function renderCartBadge() {
  const badges = document.querySelectorAll('.cart-count');
  badges.forEach(function (b) { b.textContent = cartCount(); });
}

function renderCartItems() {
  const wrap = document.getElementById('cartItems');
  const totalEl = document.getElementById('cartTotal');
  if (!wrap) return;
  const cart = getCart();

  if (cart.length === 0) {
    wrap.innerHTML = '<div class="cart-empty"><div class="emoji">🧺</div><p>ยังไม่มีสินค้าในตะกร้า</p></div>';
  } else {
    wrap.innerHTML = cart.map(function (item) {
      return '' +
        '<div class="cart-item">' +
          '<div class="thumb">' + item.icon + '</div>' +
          '<div class="cart-item-info">' +
            '<h5>' + item.name + '</h5>' +
            '<div class="price">฿' + item.price + '</div>' +
            '<div class="cart-item-qty">' +
              '<button onclick="updateCartQty(\'' + item.id + '\', -1)">−</button>' +
              '<span>' + item.qty + '</span>' +
              '<button onclick="updateCartQty(\'' + item.id + '\', 1)">+</button>' +
            '</div>' +
          '</div>' +
          '<div class="cart-item-remove" onclick="removeFromCart(\'' + item.id + '\')" style="cursor:pointer">ลบ</div>' +
        '</div>';
    }).join('');
  }
  if (totalEl) totalEl.textContent = '฿' + cartTotal().toLocaleString();
}

function bindCartUI() {
  const openBtns = document.querySelectorAll('[data-cart-open]');
  const overlay = document.getElementById('cartOverlay');
  const drawer = document.getElementById('cartDrawer');
  const closeBtn = document.getElementById('cartClose');

  function open() {
    renderCartItems();
    if (overlay) overlay.classList.add('open');
    if (drawer) drawer.classList.add('open');
  }
  function close() {
    if (overlay) overlay.classList.remove('open');
    if (drawer) drawer.classList.remove('open');
  }

  openBtns.forEach(function (b) { b.addEventListener('click', open); });
  if (closeBtn) closeBtn.addEventListener('click', close);
  if (overlay) overlay.addEventListener('click', close);

  const checkoutBtn = document.getElementById('checkoutBtn');
  if (checkoutBtn) {
    checkoutBtn.addEventListener('click', function () {
      const cart = getCart();
      if (cart.length === 0) {
        showToast('กรุณาเลือกสินค้าก่อนสั่งซื้อ');
        return;
      }
      const form = document.createElement('form');
      form.method = 'POST';
      form.action = 'process_order.php';
      const input = document.createElement('input');
      input.type = 'hidden';
      input.name = 'cart_data';
      input.value = JSON.stringify(cart);
      form.appendChild(input);
      document.body.appendChild(form);
      form.submit();
    });
  }
  renderCartItems();
}

function bindAddToCartButtons() {
  document.querySelectorAll('.add-btn[data-id]').forEach(function (btn) {
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      addToCart(
        btn.dataset.id,
        btn.dataset.name,
        parseFloat(btn.dataset.price),
        btn.dataset.icon || '🧇',
        1
      );
    });
  });
}

/* ---------- Product detail qty control ---------- */
function bindQtyControl() {
  const dec = document.getElementById('qtyDec');
  const inc = document.getElementById('qtyInc');
  const display = document.getElementById('qtyValue');
  const addBtn = document.getElementById('detailAddBtn');
  if (!display) return;
  let qty = 1;

  if (dec) dec.addEventListener('click', function () {
    if (qty > 1) { qty--; display.textContent = qty; }
  });
  if (inc) inc.addEventListener('click', function () {
    qty++; display.textContent = qty;
  });
  if (addBtn) addBtn.addEventListener('click', function () {
    addToCart(addBtn.dataset.id, addBtn.dataset.name, parseFloat(addBtn.dataset.price), addBtn.dataset.icon, qty);
  });
}

/* ---------- Menu search + filter ---------- */
function initMenuFilters() {
  const searchInput = document.getElementById('menuSearch');
  const tabs = document.querySelectorAll('.filter-tabs button');
  const cards = document.querySelectorAll('.product-card[data-cat]');
  const sections = document.querySelectorAll('[data-section]');
  const noResults = document.getElementById('noResults');

  if (!cards.length) return;

  function applyFilter() {
    const activeTab = document.querySelector('.filter-tabs button.active');
    const cat = activeTab ? activeTab.dataset.filter : 'all';
    const q = (searchInput ? searchInput.value : '').trim().toLowerCase();
    let visibleCount = 0;

    cards.forEach(function (card) {
      const matchesCat = (cat === 'all') || (card.dataset.cat === cat);
      const matchesSearch = !q || card.dataset.name.toLowerCase().indexOf(q) !== -1;
      const visible = matchesCat && matchesSearch;
      card.style.display = visible ? '' : 'none';
      if (visible) visibleCount++;
    });

    sections.forEach(function (sec) {
      const visibleInSection = sec.querySelectorAll('.product-card[data-cat]:not([style*="display: none"])').length;
      sec.style.display = (cat === 'all' || cat === sec.dataset.section) && visibleInSection > 0 ? '' : 'none';
    });

    if (noResults) noResults.style.display = visibleCount === 0 ? 'block' : 'none';
  }

  tabs.forEach(function (tab) {
    tab.addEventListener('click', function () {
      tabs.forEach(function (t) { t.classList.remove('active'); });
      tab.classList.add('active');
      applyFilter();
    });
  });

  if (searchInput) searchInput.addEventListener('input', applyFilter);
  applyFilter();
}
